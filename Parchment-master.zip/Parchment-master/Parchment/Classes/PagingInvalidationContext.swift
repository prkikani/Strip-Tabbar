import UIKit

open class PagingInvalidationContext: UICollectionViewLayoutInvalidationContext {
  var invalidateSizes: Bool = false
}
