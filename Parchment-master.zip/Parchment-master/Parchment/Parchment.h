//
//  Parchment.h
//  Parchment
//
//  Created by Martin on 2016-01-23.
//  Copyright © 2016 Martin Rechsteiner. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Parchment.
FOUNDATION_EXPORT double ParchmentVersionNumber;

//! Project version string for Parchment.
FOUNDATION_EXPORT const unsigned char ParchmentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Parchment/PublicHeader.h>


