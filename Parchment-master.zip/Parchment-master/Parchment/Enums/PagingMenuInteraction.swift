import Foundation

public enum PagingMenuInteraction {
  case scrolling
  case swipe
  case none
}
