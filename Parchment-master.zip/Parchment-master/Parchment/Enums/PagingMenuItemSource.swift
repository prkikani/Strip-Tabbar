import Foundation
import UIKit

public enum PagingMenuItemSource {
	case `class`(type: PagingCell.Type)
	case nib(nib: UINib)
}
