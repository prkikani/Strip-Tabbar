//
//  PolioPager.h
//  PolioPager
//
//  Created by Yuiga Wada on 2019/08/22.
//  Copyright © 2019 Yuiga Wada. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PolioPager.
FOUNDATION_EXPORT double PolioPagerVersionNumber;

//! Project version string for PolioPager.
FOUNDATION_EXPORT const unsigned char PolioPagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PolioPager/PublicHeader.h>


