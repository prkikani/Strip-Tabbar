---
name: "\U0001F31F Feature request"
about: Suggest an idea for this project
title: ''
labels: "\U0001F31FEnhancement"
assignees: YuigaWada

---

<!---You don't have to fill in all fields--->

# **Describe the request**
A clear and concise description of what your request is.

# **Purpose**
Add your clear idea of why we need this feature.

# **Todo**
If you think of anything about todo, write down here.
